# !/bin/sh
fio /root/test.fio -directory /mnt -output /root/test.result